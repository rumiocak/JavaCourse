package io.kodlama.entities;

public class Educator extends Base {

    public Educator(int id, String name) {
        super(id, name);
    }
}
