package io.kodlama.entities;

public class Category extends Base {

    public Category(int id, String name) {
        super(id, name);
    }
}
