package io.kodlama.core.logging;

public interface Logger {

    void log(String data);

}
