package io.kodlama.dataAccess;

public abstract class EducatorDao implements ProductDao{
}
