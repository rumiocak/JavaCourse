package io.kodlama.dataAccess;

import io.kodlama.entities.Base;

public interface ProductDao {

    void add(Base base);
}
