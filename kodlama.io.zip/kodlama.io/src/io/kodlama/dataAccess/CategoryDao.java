package io.kodlama.dataAccess;

public abstract class CategoryDao implements ProductDao {
}
