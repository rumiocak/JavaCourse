package io.kodlama.dataAccess;

public abstract class CourseDao implements ProductDao {
}
