package io.kodlama.business;

import io.kodlama.entities.Base;

public interface IProductManager {

    void add(Base base) throws Exception;
}
